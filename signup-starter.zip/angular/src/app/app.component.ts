import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-signup></app-signup>'
})
export class AppComponent {}
