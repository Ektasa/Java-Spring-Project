Place google.png and outlook.png icons here (optional).
