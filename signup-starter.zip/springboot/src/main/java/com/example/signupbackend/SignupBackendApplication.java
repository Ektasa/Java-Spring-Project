package com.example.signupbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignupBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(SignupBackendApplication.class, args);
    }
}
